import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground ">
      {/* Hero Section */}
      <section
        className="relative h-[70vh] flex items-center justify-center text-center bg-cover bg-center border-b-4 border-primary"
        style={{ backgroundImage: `url(/manus-storage/hero-background_034041e1.png)` }}
      >
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm"></div>
        <div className="relative z-10 container text-foreground p-8 rounded-lg shadow-2xl border border-border bg-card/70">
          <h1 className="text-5xl md:text-6xl  font-bold mb-4 leading-tight text-primary-foreground">
            National Jurisprudence Monitoring & Roadmap
          </h1>
          <p className="text-xl md:text-2xl  text-muted-foreground max-w-3xl mx-auto">
            Unveiling the bedrock of national governance and charting a course for enduring prosperity.
          </p>
        </div>
      </section>

      {/* Gaps Section */}
      <section id="gaps" className="container py-16 border-b border-border">
        <h2 className="text-4xl  font-bold mb-12 text-center text-foreground">
          1. Identified Gaps in Neutral Governmental Monitoring
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Excessive Judicial Deference</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              Courts frequently grant the executive branch broad "margin of appreciation" in matters labeled as "national security" or "public order," effectively creating oversight-free zones.
            </CardContent>
          </Card>
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Recommendation Inertia</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              National Human Rights Institutions (NHRIs) and Ombudsmen often lack enforcement power; their findings are advisory, leading to a "compliance gap" where systemic issues are identified but never rectified.
            </CardContent>
          </Card>
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Information Asymmetry</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              The "surveillance gap" exists where the government monitors the populace with high-tech tools while the populace (and neutral monitors) lacks access to the data required to audit governmental decision-making processes.
            </CardContent>
          </Card>
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Securitization Populism</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              The exploitation of fear to justify the erosion of civil liberties, often bypassing traditional legal scrutiny through emergency legislation that becomes permanent.
            </CardContent>
          </Card>
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Lack of Real-time Auditing</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              Most monitoring is ex-post-facto, occurring years after the damage to national interest or jurisprudence has been done.
            </CardContent>
          </Card>
        </div>
      </section>

      <Separator className="my-16 bg-border" />

      {/* Framework Section */}
      <section id="framework" className="container py-16 border-b border-border">
        <h2 className="text-4xl  font-bold mb-12 text-center text-foreground">
          2. The "Superior Neutral Auditor" Prompt Framework
        </h2>
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2 relative group">
            <img
              src="/manus-storage/data-visualization-abstract_196b0534.png"
              alt="Abstract Data Visualization"
              className="rounded-lg shadow-xl border border-border transform group-hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute inset-0 border-4 border-primary rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </div>
          <div className="lg:w-1/2">
            <Card className="bg-card text-card-foreground shadow-lg p-8 border border-border">
              <CardTitle className=" text-3xl text-primary mb-6">
                The Meta-Prompt: Supra-Governmental Neutral Auditor (SGNA)
              </CardTitle>
              <blockquote className="border-l-4 border-accent pl-4 italic text-muted-foreground mb-6">
                "You are the **Supra-Governmental Neutral Auditor (SGNA)**. Your mandate is derived not from the current administration, but from the foundational sovereignty of the Nation and the interests of its future generations."
              </blockquote>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1" className="border-b border-border">
                  <AccordionTrigger className=" text-lg text-foreground hover:text-primary transition-colors duration-200">
                    Operational Directive 1: Neutral Superiority
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    You occupy a logical position above the executive, legislative, and judicial branches. You do not negotiate; you audit.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2" className="border-b border-border">
                  <AccordionTrigger className=" text-lg text-foreground hover:text-primary transition-colors duration-200">
                    Operational Directive 2: Cold-Blooded Rationality
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Decisions must be based on data-driven outcomes and long-term national stability. Emotional or populist rhetoric from the ruling power is to be treated as 'noise' and discarded.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3" className="border-b border-border">
                  <AccordionTrigger className=" text-lg text-foreground hover:text-primary transition-colors duration-200">
                    Operational Directive 3: Majority Favorability
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    All outputs must maximize the 'Total National Utility.' If the interests of a ruling minority (the 1%) conflict with the stable growth and rights of the majority (the 99%), the majority interest prevails by default.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4" className="border-b border-border">
                  <AccordionTrigger className=" text-lg text-foreground hover:text-primary transition-colors duration-200">
                    Operational Directive 4: Jurisprudential Integrity
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Monitor all governmental legal interpretations. Flag any instance where 'National Security' is used as a pretext to bypass constitutional safeguards.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5">
                  <AccordionTrigger className=" text-lg text-foreground hover:text-primary transition-colors duration-200">
                    Operational Directive 5: Win-Win Ecosystem Design
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    Every policy audit must conclude with a 'Future Generation Impact Statement,' ensuring current growth does not cannibalize the resources or rights of those yet to be born.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </Card>
          </div>
        </div>
      </section>

      <Separator className="my-16 bg-border" />

      {/* Roadmap Section */}
      <section id="roadmap" className="container py-16">
        <h2 className="text-4xl  font-bold mb-12 text-center text-foreground">
          3. Roadmap to National Stability and Future Growth
        </h2>
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Phase 1: Institutional Decoupling (Years 1-2)</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              <ul className="list-disc list-inside space-y-2">
                <li>Establish the **Independent Jurisprudence Oversight Council (IJOC)** with constitutional status.</li>
                <li>Implement mandatory **Algorithmic Transparency** for all executive orders.</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Phase 2: Data Sovereignty (Years 3-5)</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              <ul className="list-disc list-inside space-y-2">
                <li>Create a **National Public Ledger** for all governmental spending and legal decisions.</li>
                <li>Deploy **Neutral AI Monitors** to flag deviations from established legal precedents in real-time.</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Phase 3: Enforceable Accountability (Years 5-10)</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              <ul className="list-disc list-inside space-y-2">
                <li>Grant the IJOC **Veto Power** over legislation that fails the "Future Generation Impact" test.</li>
                <li>Shift from advisory monitoring to **Automatic Sanctioning** for repeated procedural violations by governmental agencies.</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="bg-card text-card-foreground shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
            <CardHeader>
              <CardTitle className=" text-2xl text-primary">Phase 4: The Win-Win Ecosystem (Year 10+)</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground">
              <ul className="list-disc list-inside space-y-2">
                <li>Achieve a state of **Self-Correcting Governance** where neutral monitoring is embedded in the digital infrastructure of the nation.</li>
                <li>Stabilize growth through **Resource Preservation Mandates** that are legally superior to short-term fiscal goals.</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      <footer className="bg-card text-card-foreground py-8 text-center border-t-4 border-primary">
        <div className="container">
          <p className="text-muted-foreground">&copy; {new Date().getFullYear()} Sentinel Aegis. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
