import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="bg-card text-card-foreground shadow-lg py-4 px-6">
      <div className="container flex justify-between items-center">
        <Link href="/">
          <a className="flex items-center space-x-2">
            <img src="/manus-storage/sentinel-aegis-logo_c284236e.png" alt="Sentinel Aegis Logo" className="h-8 w-8" />
            <span className="text-xl font-sans font-bold">Sentinel Aegis</span>
          </a>
        </Link>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <Button variant="ghost" asChild>
                <Link href="#gaps">Gaps</Link>
              </Button>
            </li>
            <li>
              <Button variant="ghost" asChild>
                <Link href="#framework">Framework</Link>
              </Button>
            </li>
            <li>
              <Button variant="ghost" asChild>
                <Link href="#roadmap">Roadmap</Link>
              </Button>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
