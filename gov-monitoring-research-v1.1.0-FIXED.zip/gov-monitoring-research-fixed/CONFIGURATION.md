# Configuration Guide

This document provides detailed information about configuring the National Jurisprudence Monitoring & Roadmap application.

## Environment Variables

All environment variables are optional. The application will work without any configuration, but certain features can be enabled by setting these variables.

### Analytics Configuration

**Purpose**: Enable usage analytics tracking on the website

**Variables**:
- `VITE_ANALYTICS_ENDPOINT`: The base URL of your analytics service
- `VITE_ANALYTICS_WEBSITE_ID`: Your website ID for the analytics service

**Example**:
```env
VITE_ANALYTICS_ENDPOINT=https://analytics.example.com
VITE_ANALYTICS_WEBSITE_ID=abc123def456
```

**Note**: If these variables are not set, analytics will be disabled. The application will function normally without them.

### Storage Backend Configuration

**Purpose**: Enable the `/manus-storage/` proxy for serving images from a remote storage service

**Variables**:
- `BUILT_IN_FORGE_API_URL`: The base URL of your storage backend API
- `BUILT_IN_FORGE_API_KEY`: API key for authentication with the storage backend

**Example**:
```env
BUILT_IN_FORGE_API_URL=https://storage.example.com
BUILT_IN_FORGE_API_KEY=your-secret-api-key
```

**How it works**:
1. Components reference images using `/manus-storage/filename.png`
2. The Vite storage proxy intercepts these requests
3. It calls the storage backend to get a presigned URL
4. The image is served to the client

**Note**: If these variables are not set, requests to `/manus-storage/` will fail with a 500 error. Either configure these variables or update image paths to use local assets.

### OAuth Configuration

**Purpose**: Enable OAuth authentication for the application

**Variables**:
- `VITE_OAUTH_PORTAL_URL`: The OAuth provider's portal URL
- `VITE_APP_ID`: Your application ID registered with the OAuth provider

**Example**:
```env
VITE_OAUTH_PORTAL_URL=https://oauth.example.com
VITE_APP_ID=your-app-id
```

**Note**: OAuth functionality is not currently used in the application but is available for future implementation.

## Setup Instructions

### 1. Create Environment File

```bash
cp .env.example .env
```

### 2. Edit Environment Variables

Open `.env` in your text editor and uncomment/configure the variables you need:

```env
# Enable analytics
VITE_ANALYTICS_ENDPOINT=https://analytics.example.com
VITE_ANALYTICS_WEBSITE_ID=your-website-id

# Enable storage backend
BUILT_IN_FORGE_API_URL=https://storage.example.com
BUILT_IN_FORGE_API_KEY=your-api-key
```

### 3. Rebuild the Application

After changing environment variables, rebuild the application:

```bash
pnpm run build
```

## Asset Management

### Using Local Assets

1. Place image files in the `attached_assets/` directory:
   ```
   attached_assets/
   ├── hero-background.png
   ├── logo.png
   └── data-visualization.png
   ```

2. Update component imports to reference local assets:
   ```tsx
   // Instead of:
   // <img src="/manus-storage/hero-background.png" />
   
   // Use:
   import heroBackground from '@assets/hero-background.png';
   <img src={heroBackground} alt="Hero Background" />
   ```

### Using Remote Storage

1. Configure storage backend variables in `.env`:
   ```env
   BUILT_IN_FORGE_API_URL=https://storage.example.com
   BUILT_IN_FORGE_API_KEY=your-api-key
   ```

2. Reference images using the `/manus-storage/` path:
   ```tsx
   <img src="/manus-storage/hero-background.png" alt="Hero Background" />
   ```

3. The storage proxy will handle fetching the image from the remote backend.

## Build-Time vs Runtime Configuration

### Build-Time Variables (Vite)

Variables prefixed with `VITE_` are embedded into the build at compile time:
- `VITE_ANALYTICS_ENDPOINT`
- `VITE_ANALYTICS_WEBSITE_ID`
- `VITE_OAUTH_PORTAL_URL`
- `VITE_APP_ID`

**Important**: These variables must be set before running `pnpm run build`. Changing them after the build requires rebuilding.

### Runtime Variables (Node.js)

Variables without the `VITE_` prefix are available at runtime:
- `BUILT_IN_FORGE_API_URL`
- `BUILT_IN_FORGE_API_KEY`
- `PORT` (server port, default: 3000)
- `NODE_ENV` (production/development)

**Important**: These can be changed without rebuilding.

## Deployment Configuration

### Development

```bash
# Install dependencies
pnpm install

# Start dev server (port 3000)
pnpm run dev
```

### Production

```bash
# Build for production
pnpm run build

# Start production server
NODE_ENV=production pnpm run start
```

### Docker Deployment

Example Dockerfile:

```dockerfile
FROM node:22-alpine

WORKDIR /app

# Copy project files
COPY . .

# Install dependencies
RUN pnpm install --frozen-lockfile

# Build application
RUN pnpm run build

# Expose port
EXPOSE 3000

# Start server
CMD ["pnpm", "run", "start"]
```

Build and run:

```bash
docker build -t gov-monitoring-research .
docker run -p 3000:3000 \
  -e BUILT_IN_FORGE_API_URL=https://storage.example.com \
  -e BUILT_IN_FORGE_API_KEY=your-api-key \
  gov-monitoring-research
```

## Troubleshooting

### Analytics not working

**Problem**: Analytics script is not loading

**Solutions**:
1. Verify `VITE_ANALYTICS_ENDPOINT` and `VITE_ANALYTICS_WEBSITE_ID` are set in `.env`
2. Rebuild the application: `pnpm run build`
3. Check browser console for errors
4. Verify the analytics service is accessible from your network

### Images not loading

**Problem**: Images show broken image icon

**Solutions**:
1. **For `/manus-storage/` paths**:
   - Verify `BUILT_IN_FORGE_API_URL` and `BUILT_IN_FORGE_API_KEY` are set
   - Check that the storage backend is accessible
   - Verify the API key is valid

2. **For local assets**:
   - Verify files exist in `attached_assets/` directory
   - Check file paths in components
   - Verify file permissions

### Port already in use

**Problem**: "Port 3000 already in use" error

**Solutions**:
1. Use a different port: `PORT=3001 pnpm run dev`
2. Kill the process using port 3000: `lsof -ti:3000 | xargs kill -9`
3. The dev server will automatically use the next available port

### Build fails

**Problem**: Build process fails with errors

**Solutions**:
1. Clear cache: `rm -rf node_modules pnpm-lock.yaml dist`
2. Reinstall: `pnpm install`
3. Rebuild: `pnpm run build`
4. Check for TypeScript errors: `pnpm run check`

## Security Considerations

- **Never commit `.env` file** to version control. Use `.env.example` instead.
- **Protect API keys**: Keep `BUILT_IN_FORGE_API_KEY` and other secrets secure.
- **Use HTTPS**: In production, always use HTTPS for storage backend URLs.
- **Validate environment**: Verify all required variables are set before deployment.

## Additional Resources

- [Vite Documentation](https://vitejs.dev/)
- [React Documentation](https://react.dev/)
- [Tailwind CSS Documentation](https://tailwindcss.com/)
- [Express.js Documentation](https://expressjs.com/)
